# slideshow-powerbi
Slideshow for PowerBi Report
